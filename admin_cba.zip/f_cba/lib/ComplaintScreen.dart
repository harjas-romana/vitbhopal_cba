import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ComplaintScreen extends StatefulWidget {
  @override
  _ComplaintScreenState createState() => _ComplaintScreenState();
}

class _ComplaintScreenState extends State<ComplaintScreen> {
  Future<List<QueryDocumentSnapshot>> fetchLatestComplaintsFromFirestore() async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('complaints')
        .orderBy('Date', descending: true)
        .get();
    return querySnapshot.docs;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Complaints'),
      ),
      body: FutureBuilder<List<QueryDocumentSnapshot>>(
        future: fetchLatestComplaintsFromFirestore(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Text('No complaints available.'),
            );
          } else {
            final complaints = snapshot.data!;
            return ListView.builder(
              itemCount: complaints.length,
              itemBuilder: (context, index) {
                final complaint = complaints[index].data() as Map<String, dynamic>;
                return ListTile(
                  title: Text('Category: ${complaint['Category'] ?? 'N/A'}'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Priority: ${complaint['Priority'] ?? 'N/A'}'),
                      Text('Proctor Name: ${complaint['Proctor Name'] ?? 'N/A'}'),
                      Text('Proctor Email: ${complaint['Proctor Email'] ?? 'N/A'}'),
                      Text('Location: ${complaint['Location'] ?? 'N/A'}'),
                      Text('Description: ${complaint['Description'] ?? 'N/A'}'),
                    ],
                  ),
               
                );
              },
            );
          }
        },
      ),
    );
  }
}
