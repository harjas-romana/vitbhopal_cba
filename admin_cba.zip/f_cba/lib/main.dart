import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'ComplaintScreen.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  ); // Initialize Firebase
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Complaints App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AdminHomeScreen(),
    );
  }
}

//


class AdminHomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Home'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Admin Home Screen'),
            ElevatedButton(
              onPressed: () {
                // Navigate to ComplaintScreen for admins
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ComplaintScreen()),
                );
              },
              child: Text('View Complaints'),
            ),
          ],
        ),
      ),
    );
  }
}
